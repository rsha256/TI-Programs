SAT II MATH Dojo
=-=-=-=-=-=-=-=-=
By Tristan Dahl

Dojo Productions presents... yet another amazing math program by T.D.!  Here are the features (BTW if you couldn't figure it out, this program was made for use on the SAT II MATH Level IIC Test, so the topics are a bit random):  Linear Functions; Quadratic Functions (a good quad. formula section); Sectors (Deg. and Rad. as in [MLT�]); Trig - csc/sec/cot, Law of cos, Law of sin, Half Angle, Double Angle, Pythagorean Identities, Sum and Difference, Negatives, Cofunction; Conics - circle, ellipse, hyperbola, parabola; DeMoivre's Theorem; Binomial Expansion; Probability; Sequences and Series; Vectors; Determinants; and Geometry - triangle, rhombus, cylinder, cone, and sphere.

This program does a lot.  For all of the operation-cable parts, the answers are quick and you don't have to do the work!  All of the listed parts (*reminisces about MLT Pro*) are great to either study with or be used as "reminders" on tests :)

Thank you for downloading!  Questions, comments, hate mail:

madtrumpet514@hotmail.com

DOJO PRODUCTIONS =-=-= http://zamboni182.tripod.com